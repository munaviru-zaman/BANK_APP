import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServicesService } from '../services/data-services.service';

@Component({
  selector: 'credit-card',
  templateUrl: './credit-card.component.html',
  styleUrls: ['./credit-card.component.css'],
})
export class CreditCardComponent implements OnInit {
  name: any = '';
  acno: any;
  balance: any;
  pan: any;
  aadhar: any;
  dummyarray: any = [];
  constructor(private db: DataServicesService, private route: Router) {}

  ngOnInit(): void {}

  getacno(event: any) {
    this.acno = event.target.value;
    if (this.acno in this.db.database) {
      this.name = this.db.database[this.acno]['name'];
      this.balance = this.db.database[this.acno]['balance'];
      console.log(this.name);
    }
  }

  apply() {
    this.db.database[this.acno]['PAN'] = this.pan;
    this.db.database[this.acno]['Aadhar'] = this.aadhar;
    console.log(this.db.database[this.acno]);
    console.log(this.db.database);
    this.dummyarray.push(this.db.database[this.acno]);
    console.log('this.dummyarray', this.dummyarray);
  }
}
