import { DirectivesDirective } from './directives.directive';

describe('DirectivesDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectivesDirective();
    expect(directive).toBeTruthy();
  });
});
